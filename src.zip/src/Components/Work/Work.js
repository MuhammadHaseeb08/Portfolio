import React from 'react'
import Slider from '../Slider/Slider';
import Slider2 from '../Slider2/Slider2';


export default function Worke() {
  return (
    <div >
      <div >
      <Slider/>
      </div>
      {/* <Slider2/> */}

    </div>
  )
}
